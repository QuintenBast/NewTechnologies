﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour {

    public List<Lookable> blocks = new List<Lookable>();
    public List<bool> blockbool = new List<bool>();
    public SpriteRenderer sprite;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		foreach(Lookable block in blocks)
        {
            int i = 0;
            int q = 0;
            if (block.lookedAt)
            {
                blockbool[i] = true;
                i++;
            }
            foreach(bool x in blockbool)
            {
                if(x == true)
                {
                    foreach(Lookable z in blocks)
                    {
                        z.myRenderer.material.color = Color.green;
                        sprite.enabled = true;
                    }
                }
                else
                {
                    return;
                }
            }
        }

	}
}
